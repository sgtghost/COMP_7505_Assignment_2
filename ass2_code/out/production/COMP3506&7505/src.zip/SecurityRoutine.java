import java.util.*;
import java.util.stream.Collectors;

public class SecurityRoutine extends SecurityRoutineBase {

    /* Implement all the necessary methods here */
    private List<List<AreaBase>> graphList;
    private List<AreaBase> areaBases;
    private List<AreaBase> fathers;
    private List<Integer> check;
    private List<Integer[]> timeStamp;
    private int time = 0;
    /*
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        REMOVE THE MAIN FUNCTION BEFORE SUBMITTING TO THE AUTOGRADER
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

        The following main function is provided for simple debugging only

        Note: to enable assertions, you need to add the "-ea" flag to the
        VM options of SecurityRoutine's run configuration
     */
//    public static void main(String[] args) {
//        SecurityRoutine g = new SecurityRoutine();
//        AreaBase areaZ = g.insertArea(new AreaBase("Z"));
//        AreaBase areaA = g.insertArea(new AreaBase("A"));
//        AreaBase areaB = g.insertArea(new AreaBase("B"));
//        AreaBase areaC = g.insertArea(new AreaBase("C"));
//
//
//        g.addOrder(areaZ, areaA);
//        g.addOrder(areaA, areaB);
//        g.addOrder(areaB, areaC);
//        g.addOrder(areaA, areaC);
//        List<AreaBase> t = g.calculateTotalOrder();
//
//        assert t.stream()
//                .map(AreaBase::getId)
//                .collect(Collectors.toList()).equals(List.of("Z", "A", "B", "C"));
//    }

    public SecurityRoutine() {
        this.graphList = new ArrayList<>();
        this.areaBases = new ArrayList<>();
        this.check = new ArrayList<>();
        this.timeStamp = new ArrayList<>();
        this.fathers = new ArrayList<>();
    }


    /**
     * Adds the given area to the SecurityBase, and returns the added area.
     *
     * @param area area to add
     * @return area that was added
     */
    @Override
    public AreaBase insertArea(AreaBase area) {
        this.areaBases.add(area);
        int index = this.areaBases.indexOf(area);


        this.graphList.add(index, new ArrayList<>());

        this.check.add(index, 0);
        Integer[] arraysToAdd = new Integer[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.timeStamp.add(index, arraysToAdd);

        this.fathers.add(index, null);
        return area;
    }

    /**
     * Adds the order between two areas, where area1 should be checked
     * before area2.
     *
     * @param area1 area that should be checked before
     * @param area2 area that should be checked after
     */
    @Override
    public void addOrder(AreaBase area1, AreaBase area2) {
        int index = this.areaBases.indexOf(area1);
        this.graphList.get(index).add(area2);
    }

    /**
     * Calculates and returns the order in which the areas must be checked
     * by the security team.
     *
     * @return list of areas in order, or null if it is not possible to define
     * the order
     */
    @Override
    public List<AreaBase> calculateTotalOrder() {
        try{
            return DFS();
        } catch (Exception e) {
            return null;
        }
//        reverseGraph();
//        List<AreaBase> reverseResult = DFS();
//        reverseGraph();
//        for (AreaBase a : this.areaBases) {
//            if (!result.contains(a) && !reverseResult.contains(a)) {
//                return null;
//            }
//        }
    }

//    private void reverseGraph() {
//        initialise();
//        List<AreaBase[]> result = new ArrayList<>();
//        for (List<AreaBase> i : this.graphList) {
//            if (i.size() > 0) {
//                AreaBase ogStart = this.areaBases.get(this.graphList.indexOf(i));
//                for (AreaBase ogEnd : i) {
//                    AreaBase[] temp = new AreaBase[] {ogEnd, ogStart};
//                    result.add(temp);
//                }
//            }
//        }
//
//        for (int i = 0; i < this.graphList.size(); i++) {
//            this.graphList.set(i,new ArrayList<>());
//        }
//        for (AreaBase[] i: result) {
//           addOrder(i[0], i[1]);
//        }
//    }

    private void initialise() {
        for (AreaBase a : this.areaBases) {
            int index = this.areaBases.indexOf(a);
            this.check.set(index,0);
            this.fathers.set(index, null);
        }
    }

    private List<AreaBase> DFS () throws Exception {
        List<AreaBase> result = new LinkedList<>();
        initialise();
        this.time = 0;
        Map<AreaBase, Integer> endTime = new HashMap<>();
        for (AreaBase a : this.areaBases) {
            int index = this.areaBases.indexOf(a);
            int check = this.check.get(index);
            if (check == 0) {
                DFSVisit(a);
            }
        }
        for (AreaBase a : this.areaBases) {
            int index = this.areaBases.indexOf(a);
            int check = this.check.get(index);
            if (check == 2 && (this.fathers.get(index) != null || !this.graphList.get(index).isEmpty())) {
                int timeTemp = this.timeStamp.get(index)[1];
                endTime.put(a, timeTemp);
            }
        }


        List<Map.Entry<AreaBase, Integer>> list = new ArrayList<>(endTime.entrySet());
        list.sort(Map.Entry.comparingByValue());
        for (Map.Entry<AreaBase, Integer> i : list) {
            result.add(i.getKey());
        }
        Collections.reverse(result);
        return result;
    }

    private void DFSVisit(AreaBase a) throws Exception{
        this.time += 1;
        int indexA = this.areaBases.indexOf(a);

        Integer[] modified = this.timeStamp.get(indexA);
        modified[0] = this.time;
        this.check.set(indexA, 1);
        List<AreaBase> ends = this.graphList.get(indexA);
        if (!ends.isEmpty()) {
            for (AreaBase b : ends) {
                int indexB = this.areaBases.indexOf(b);
                if (this.fathers.get(indexB) == null) {
                    this.fathers.set(indexB, a);
                    if (this.check.get(indexB) == 0) {
                        DFSVisit(b);
                    } else if(this.check.get(indexB) == 1) {
                        throw new Exception("Back edge detected");
                    }
                }
            }
        }

        this.check.set(indexA, 2);
        this.time += 1;
        modified[1] = this.time;
    }

    private List<AreaBase> surroundings(AreaBase start) {
        List<AreaBase> result = new ArrayList<>();
        int index = this.areaBases.indexOf(start);
        for (List<AreaBase> a : this.graphList) {
            if (!a.isEmpty() && a.contains(start)) {
                int toAdd =  this.graphList.indexOf(a);
                result.add(this.areaBases.get(toAdd));
            }
        }
        result.addAll(this.graphList.get(index));
        return result;
    }
}


